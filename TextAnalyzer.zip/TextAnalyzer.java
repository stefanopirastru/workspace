import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.Iterator;

//Analisi di efficienza: 
//Supponiamo che il file contenga N parole
public class TextAnalyzer {	
	
	public static ArrayList<Entry> readWords(Scanner in) {
		// Inizializzo la mappa delle parole distinte:
		// - chiave: stringa corrispondente alla parola
		// - valore: numero di occorrenze
		ArrayList<Entry> words = new ArrayList<Entry>(); 

		while (in.hasNext()) {
			String w = in.next();
			Entry temp = new Entry(w,0);
			// Per ogni parola w, verifico se questa compare 
			// in words o meno. Questa ricerca richiede O(N)
			int wIndex = words.indexOf(temp);
			if (wIndex == -1) {
				// Se w non compare in E, la inserisco in E
				// con occorrenze (value) pari a 0
				// Questo richiede O(1) *ammortizzato*
				words.add(temp);
			} else {
				// Se w compare in E, salvo in temp il
				// riferimento alla entry corrispondente
				// Dato che ho già l'indice e 'words' è un array
				// dinamico, questa operazione richiede O(1)
				temp = words.get(wIndex);
			}
			// Incremento la entry (nuova o trovata in "words") di 1
			temp.value += 1;
		}
		
		// Su N parole lette il costo di readWords è quindi O(N^2) perché
		// - la ricerca in words richiede, per ogni parola, O(N), e
		// - l'inserimento di N parole nel vettore dinamico ha un 
		//   costo complessivo pari ad O(N).
		// Se contabilizzo i due contributi separatamente:
		// - la ricerca mi richiede un tempo complessivo O(N^2), e 
		// - l'inserimento mi richiede un tempo complessivo O(N).
		// Pertanto, per il teorema della somma degli O, il costo complessivo
		// risulta essere O(N^2).
	
		return words;
	}
	
	public static void main(String[] args) {
		
		if (args.length < 1) {
			System.out.println("Manca il nome del file da analizzare!");
			System.out.println("Utilizzo: java TextAnalyzer <file di testo>");
			System.exit(0);
		}
		
		assert(args.length >= 1);
		// Sappiamo che il programma ha almeno un argomento
		// da linea di comando
		String textFileName = args[0];
		
				
		// Leggo il file parola per parola
		FileReader inFile = null;
		try {
			inFile = new FileReader(textFileName);
		} catch (Exception e) {
			System.err.println("Non posso aprire il file:" + textFileName);
			System.exit(0);
		}
		assert(inFile != null);
		// Sappiamo che lo stream di input non è null
		Scanner scanner = new Scanner(inFile);
		ArrayList<Entry> words = readWords(scanner);
		scanner.close();

		try {
			inFile.close();
		} catch (Exception e) {
			System.err.println("Non posso chiudere il file:" + textFileName);
		}
		
		// Al termine della lettura del file, "words" contiene
		// l'elenco di tutte le parole *distinte* del file
		// con le relative occorrenze
		
		// Per ordinare words possiamo utilizzare il metodo statico "sort" della
		// classe Collections che si trova nel package "util". Questa classe contiene
		// diversi metodi di utilità generale per operare su contenitori generici (quali ArrayList)
		// Dato che Entry implementa "Comparable" non è necessario specificare un comparatore
		// Il metodo utilizzato (vedi https://docs.oracle.com/javase/7/docs/api/java/util/Collections.html)
		// è una (sofisticata) implementazione di merge sort, quindi O(N log N)
		Collections.sort(words);
		
		// Stampa delle frequenza di tutte le parole in ordine alfabetico
		Iterator<Entry> ai = words.iterator();
		while (ai.hasNext()) {
			Entry t = ai.next();
			// Dato che in "Entry" è stato ridefinito il metodo "toString"
			// questo verrà direttamente invocato sull'oggetto t per eseguire 
			// la stampa di t
			System.out.println(t);
		}
		
		// L'operazione finale di stampa costa O(N)
		
		// Complessivamente, il costo risulta essere:
		// - O(N^2) per la prima parte (lettura e calcolo frequenze)
		// - O(N log N) per la seconda parte (ordinamento)
		// - O(N) per la terza parte (stampa statistiche)
		//
		// Per il teorema della somma degli O, il costo complessivo è O(N^2).
	}

}
