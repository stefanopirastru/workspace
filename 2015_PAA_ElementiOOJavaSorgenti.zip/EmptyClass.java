
public class EmptyClass {

}
