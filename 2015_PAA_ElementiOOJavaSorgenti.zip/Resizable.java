
public interface Resizable {

	public void resize(double percentage);
	
}
