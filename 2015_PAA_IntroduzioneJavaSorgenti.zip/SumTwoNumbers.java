
public class SumTwoNumbers {

	public static void main(String[] args) {
		int x = 20;
		int y = 30;
		System.out.print("La somma di ");
		System.out.print(x);
		System.out.print(" e ");
		System.out.print(y);
		System.out.print(" è pari a ");
		System.out.println(x + y);
		
		int[] v = new int[2];
		v[0] = x; v[1] = y;
		System.out.println(v);
	}

}
